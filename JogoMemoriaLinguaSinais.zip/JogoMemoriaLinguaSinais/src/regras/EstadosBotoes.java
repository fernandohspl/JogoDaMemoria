package regras;

/**
 *
 * @author fernando.lima
 */

public enum EstadosBotoes {
    NORMAL, SELECIONADO, PARES_ENCONTRADOS;
}
