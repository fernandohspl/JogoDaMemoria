package JogoDaMemorialibras;

import telas.TelaPrincipal;


/**
 *
 * @author fernando.lima
 */
public class JogoDaMemorialibras {
  public static void main(String args[]){
      TelaPrincipal tela = new TelaPrincipal();
  
    }
    
}
