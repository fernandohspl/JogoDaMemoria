/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package memoria;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Thiago
 */
public class Temporizador implements ActionListener {
    
    int status =0;
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {

    }
    
    public int mudaStatus(){
        return 3;
    }


}



